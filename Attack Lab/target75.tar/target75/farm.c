/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_334(unsigned *p)
{
    *p = 3281031256U;
}

unsigned getval_258()
{
    return 3347662977U;
}

unsigned getval_448()
{
    return 3277372420U;
}

unsigned addval_102(unsigned x)
{
    return x + 2346894200U;
}

unsigned getval_312()
{
    return 2428993864U;
}

void setval_292(unsigned *p)
{
    *p = 2428995912U;
}

void setval_346(unsigned *p)
{
    *p = 3281031192U;
}

void setval_186(unsigned *p)
{
    *p = 3284634952U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_338(unsigned x)
{
    return x + 2109981325U;
}

unsigned addval_179(unsigned x)
{
    return x + 1656999561U;
}

void setval_427(unsigned *p)
{
    *p = 2430634312U;
}

unsigned getval_193()
{
    return 3526938249U;
}

unsigned addval_158(unsigned x)
{
    return x + 3524841097U;
}

unsigned getval_148()
{
    return 3286272328U;
}

unsigned getval_295()
{
    return 2425540233U;
}

unsigned addval_270(unsigned x)
{
    return x + 2497743176U;
}

unsigned addval_301(unsigned x)
{
    return x + 3224421001U;
}

void setval_160(unsigned *p)
{
    *p = 3286272332U;
}

void setval_155(unsigned *p)
{
    *p = 2425406088U;
}

unsigned addval_131(unsigned x)
{
    return x + 3269495112U;
}

unsigned addval_105(unsigned x)
{
    return x + 3281047949U;
}

void setval_320(unsigned *p)
{
    *p = 3674263945U;
}

void setval_473(unsigned *p)
{
    *p = 3683962505U;
}

void setval_200(unsigned *p)
{
    *p = 2497743176U;
}

unsigned addval_231(unsigned x)
{
    return x + 3286272332U;
}

unsigned addval_107(unsigned x)
{
    return x + 3285093244U;
}

void setval_233(unsigned *p)
{
    *p = 3223376265U;
}

void setval_313(unsigned *p)
{
    *p = 2430634056U;
}

void setval_170(unsigned *p)
{
    *p = 3526935177U;
}

void setval_108(unsigned *p)
{
    *p = 3229929865U;
}

unsigned getval_154()
{
    return 3674788232U;
}

void setval_388(unsigned *p)
{
    *p = 3265893223U;
}

void setval_378(unsigned *p)
{
    *p = 3225997705U;
}

unsigned getval_153()
{
    return 3682914689U;
}

unsigned getval_318()
{
    return 3674263177U;
}

unsigned getval_398()
{
    return 2425409931U;
}

unsigned addval_245(unsigned x)
{
    return x + 3374370433U;
}

unsigned getval_169()
{
    return 3523789321U;
}

unsigned getval_410()
{
    return 3227566729U;
}

unsigned addval_414(unsigned x)
{
    return x + 3674784393U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
